// OGD Natural Lighting 1.0.0 - original OGD shader, no external include files.
// Restrained filmic response; not ray tracing or global illumination.
uniform float ExposureStops < ui_type = "slider"; ui_min = -1.0; ui_max = 1.0; ui_label = "Exposure (stops)"; > = 0.0;
uniform float FilmicBlend < ui_type = "slider"; ui_min = 0.0; ui_max = 1.0; ui_label = "Highlight shoulder"; > = 0.25;
uniform float Saturation < ui_type = "slider"; ui_min = 0.0; ui_max = 1.5; > = 1.02;
uniform float WarmHighlights < ui_type = "slider"; ui_min = 0.0; ui_max = 0.1; ui_label = "Warm highlights"; > = 0.012;
uniform float CoolShadows < ui_type = "slider"; ui_min = 0.0; ui_max = 0.1; ui_label = "Cool shadows"; > = 0.008;
uniform float DetailSharpness < ui_type = "slider"; ui_min = 0.0; ui_max = 1.2; ui_label = "OGD detail sharpness"; ui_tooltip = "Bounded spatial sharpening. Set to zero to compare."; > = 0.65;

texture2D OGD_BackBuffer : COLOR;
sampler2D OGD_ColorSampler
{
    Texture = OGD_BackBuffer;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = POINT;
    AddressU = CLAMP;
    AddressV = CLAMP;
};

void OGD_FullscreenVS(uint id : SV_VertexID, out float4 position : SV_Position, out float2 uv : TEXCOORD)
{
    uv = float2((id << 1) & 2, id & 2);
    position = float4(uv * float2(2.0, -2.0) + float2(-1.0, 1.0), 0.0, 1.0);
}

float3 OGD_ToLinear(float3 color)
{
    // Piecewise sRGB transfer, appropriate to the user's SDR DX11 configuration.
    return lerp(color / 12.92, pow(max((color + 0.055) / 1.055, 0.0), 2.4), step(0.04045, color));
}
float3 OGD_ToSRGB(float3 color)
{
    color = max(color, 0.0);
    return lerp(color * 12.92, 1.055 * pow(color, 1.0/2.4) - 0.055, step(0.0031308, color));
}

float4 OGD_NaturalPS(float4 position : SV_Position, float2 uv : TEXCOORD) : SV_Target
{
    float4 original = tex2D(OGD_ColorSampler, uv);
    float2 pixel = float2(1.0 / BUFFER_WIDTH, 1.0 / BUFFER_HEIGHT);
    float3 center = OGD_ToLinear(saturate(original.rgb));
    float3 north = OGD_ToLinear(saturate(tex2D(OGD_ColorSampler, uv - float2(0, pixel.y)).rgb));
    float3 south = OGD_ToLinear(saturate(tex2D(OGD_ColorSampler, uv + float2(0, pixel.y)).rgb));
    float3 east = OGD_ToLinear(saturate(tex2D(OGD_ColorSampler, uv + float2(pixel.x, 0)).rgb));
    float3 west = OGD_ToLinear(saturate(tex2D(OGD_ColorSampler, uv - float2(pixel.x, 0)).rgb));
    float3 low = min(center, min(min(north, south), min(east, west)));
    float3 high = max(center, max(max(north, south), max(east, west)));
    float contrast = dot(high-low, float3(0.2126, 0.7152, 0.0722));
    float strength = DetailSharpness * (1.0 - 0.65*smoothstep(0.1, 0.6, contrast));
    float3 detail = clamp(center - 0.25*(north+south+east+west), -0.045, 0.045);
    float3 color = clamp(center + detail*strength, max(low-0.005, 0.0), high+0.005) * exp2(ExposureStops);
    float luma = dot(color, float3(0.2126, 0.7152, 0.0722));
    // Continuous, normalized highlight shoulder: preserves black and white endpoints.
    float shoulder = luma / (0.82 + 0.18*luma);
    float target = lerp(luma, shoulder, FilmicBlend);
    color *= target / max(luma, 0.00001);
    color = lerp(target.xxx, color, Saturation);
    float highlight = smoothstep(0.45, 1.0, luma);
    float shadow = 1.0-smoothstep(0.02, 0.25, luma);
    color *= 1.0 + highlight*WarmHighlights*float3(1.0, 0.15, -0.5)
                 + shadow*CoolShadows*float3(-0.3, 0.0, 0.6);
    return float4(saturate(OGD_ToSRGB(color)), original.a);
}

technique OGD_NaturalLighting < ui_label = "OGD Natural Lighting"; ui_tooltip = "OGD filmic SDR preset. No camera shake, letterbox, forced blur or fake ray tracing."; >
{
    pass
    {
        VertexShader = OGD_FullscreenVS;
        PixelShader = OGD_NaturalPS;
    }
}
